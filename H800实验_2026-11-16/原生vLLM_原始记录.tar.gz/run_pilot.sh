#!/usr/bin/env bash
set -eu
cd /root/bayes-tmp/wanli/h800-1116/project
base=$(dirname "$PWD")
method=$1
tag=$2
model="$base/models--Qwen--Qwen3-8B/snapshots/b968826d9c46dd6066d109eabc6255188de91218"
out="$base/r/$tag"
mkdir -p "$base/r"
read -r engine helper < <(../env/bin/python -c 'import os; a=sorted(os.sched_getaffinity(0)); assert len(a)>=4; n=min(12,len(a)-2); print(",".join(map(str,a[:n])), ",".join(map(str,a[n:n+2])))')
exec ../env/bin/python scripts/gpu_python.py -m b_replay.comparison run --method "$method" --bundle bundles/Qwen3-8B/pilot_14 --arrivals arrivals/pilot_14_jps0.1_seed20261030.json --model "$model" --output "$out" --engine-cpus "$engine" --helper-cpus "$helper" --gpu-pid-policy record-only --start-timeout 600 --run-timeout 360
